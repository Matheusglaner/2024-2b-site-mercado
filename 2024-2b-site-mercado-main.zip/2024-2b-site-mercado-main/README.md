# 2024-2b-site-mercado
um mercado bom e barato
